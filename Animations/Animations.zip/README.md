# Terminal graphics
Available objects: Tree, Cow, Creeper.

Compile:
```
make
```

Run with any number of entities:
```
./output *number_of_trees* *number_of_cows* *number_of_creepers* *time (in ms)* *random seed (optional)*
```
